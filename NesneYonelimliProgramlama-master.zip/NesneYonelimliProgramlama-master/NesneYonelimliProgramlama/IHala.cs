﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NesneYonelimliProgramlama
{
    interface IHala: IMiras
    {
        void AkrabaDuzeyi();
    }
}
