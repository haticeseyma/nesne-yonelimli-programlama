﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NesneYonelimliProgramlama
{
    class Miras : IPasaDedem, IHala
    {
        public void AkrabaDuzeyi()
        {
            
        }

        public void MirasAl()
        {
            
        }

        public string MirasAlan(string adSoyad)
        {
            return string.Empty;
        }

        public void Ulke()
        {
            throw new NotImplementedException();
        }
    }
}
