﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NesneProgramlama
{
    public class YeniSinif
    {
    }
}
