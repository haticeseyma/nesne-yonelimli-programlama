﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NesneYonelimliProgramlama
{
    interface IMiras
    {
        void MirasAl();
        string MirasAlan(string adSoyad);
    }
}
